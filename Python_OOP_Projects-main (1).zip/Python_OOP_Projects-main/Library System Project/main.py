from OperationsManager import *

if __name__ == '__main__':
    main = OperationsManager()
    main.run()

