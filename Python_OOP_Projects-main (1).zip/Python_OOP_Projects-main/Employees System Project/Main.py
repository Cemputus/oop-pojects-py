from FrontendManager import *


if __name__ == "__main__":
    app = FrontendManager()
    app.run()
