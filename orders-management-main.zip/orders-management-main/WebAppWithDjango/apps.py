from django.apps import AppConfig


class WebappwithdjangoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'WebAppWithDjango'
