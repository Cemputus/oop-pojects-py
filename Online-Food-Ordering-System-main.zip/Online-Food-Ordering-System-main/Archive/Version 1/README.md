# Online-Food-Ordering-System

## Usage

`% flask run --host 0.0.0.0`

or

`% python app.py`

## Testing

### UID

* user1: 7
* user2: 8

### SID

* macdonald: 7
* starbucks: 8
