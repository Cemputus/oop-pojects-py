# OOP-Project-Online-Food-Delivery-System
A demo project for a food delivery system utilizing OOP concepts
